# inbox-fixer

Openbare informatiepagina's voor de persoonlijke Chrome-extensie **Inbox Fixer**.
Deze repository bevat alleen de homepage, privacyverklaring en opmaak; geen
extensiecode, mailboxgegevens, API-sleutels of OAuth-configuratie.

## Website activeren

1. Open **Settings → Pages** in deze repository.
2. Kies **Deploy from a branch**.
3. Selecteer branch **main** en map **/(root)**, en klik **Save**.
4. Wacht op de door GitHub bevestigde publicatie en controleer beide pagina's.

Verwachte adressen, pas beschikbaar na een geslaagde publicatie:

- Homepage: `https://arnauddeweerdt22-collab.github.io/inbox-fixer/`
- Privacyverklaring: `https://arnauddeweerdt22-collab.github.io/inbox-fixer/privacy.html`

Vul de werkende links in bij **Google Auth Platform → Branding**, samen met
appnaam **Inbox Fixer**, je ondersteuningsadres en je contactadres. Probeer daarna
bij **Audience** opnieuw **Publish app**. Dit is geen garantie op Google-verificatie;
eventuele aanvullende domein- of verificatievereisten blijven van toepassing.

Lees de privacyverklaring vóór publicatie. Ze beschrijft uitsluitend fase 1 en moet
worden bijgewerkt als de gegevensverwerking verandert.
